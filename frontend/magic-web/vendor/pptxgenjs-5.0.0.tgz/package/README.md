# PptxGenJS

![PptxGenJS Sample Slides](https://raw.githubusercontent.com/gitbrent/PptxGenJS/gh-pages/img/readme_banner.png)

![jsdelivr downloads](https://data.jsdelivr.com/v1/package/gh/gitbrent/pptxgenjs/badge)
![NPM Downloads](https://img.shields.io/npm/dm/pptxgenjs?style=flat-square)
![GitHub Repo stars](https://img.shields.io/github/stars/gitbrent/pptxgenjs?style=flat-square)
![GitHub License](https://img.shields.io/github/license/gitbrent/pptxgenjs?style=flat-square)
![TypeScript defs](https://img.shields.io/npm/types/pptxgenjs?style=flat-square)

## 🚀 Features

**PptxGenJS lets you generate professional PowerPoint presentations in JavaScript - directly from Node, React, Vite, Electron, or even the browser.**
The library outputs standards-compliant Open Office XML (OOXML) files compatible with:

- ✅ Microsoft PowerPoint
- ✅ Apple Keynote
- ✅ LibreOffice Impress
- ✅ Google Slides (via import)

Design custom slides, charts, images, tables, and templates programmatically - no PowerPoint install or license required.

### Works Everywhere

- Supports every major modern browser - desktop and mobile
- Seamlessly integrates with **Node.js**, **React**, **Angular**, **Vite**, and **Electron**
- Compatible with **PowerPoint**, **Keynote**, **LibreOffice**, and other OOXML apps

### Full-Featured

- Create all major slide objects: **text, tables, shapes, images, charts**, and more
- Define custom **Slide Masters** for consistent academic or corporate branding
- Supports **SVGs**, **animated GIFs**, **YouTube embeds**, **RTL text**, and **Asian fonts**

### Simple & Powerful

- Small, typed API for building presentation content
- Full **TypeScript definitions** for autocomplete and inline documentation
- Includes **75+ demo slides** covering every feature and usage pattern

### Destination-First Export

- Stream directly to a caller-owned **WritableStream** or **Node writable**
- Use `writeTo()` for an already-built presentation or `beginStreaming()` for page-at-a-time generation
- Keep complete PPTX files out of application memory with backpressure, ZIP64, and external staging support
- Browser applications choose an explicit file or storage destination; there is no implicit Blob fallback

### Streaming table pagination

- Stage typed table rows and commit paginated slides through `beginStreaming().tableToSlides()` without DOM capture or whole-presentation buffering

## 🌐 Live Demos

Try PptxGenJS right in your browser - no setup required.

- [Basic Slide Demo](https://gitbrent.github.io/PptxGenJS/demos/) - Build a basic presentation in seconds
- [Full Feature Showcase](https://gitbrent.github.io/PptxGenJS/demo/browser/index.html) - Explore every available feature

> Perfect for testing compatibility or learning by example - all demos run 100% in the browser.

## 📦 Installation

Choose your preferred method to install **PptxGenJS**:

### Quick Install (Node-based)

```bash
npm install pptxgenjs
```

```bash
yarn add pptxgenjs
```

### CDN (Browser Usage)

Use the bundled or minified version via [jsDelivr](https://www.jsdelivr.com/package/gh/gitbrent/pptxgenjs):

```html
<script src="https://cdn.jsdelivr.net/gh/gitbrent/pptxgenjs/dist/pptxgen.bundle.js"></script>
```

> The browser bundle includes the ZIP implementation, so no separate runtime script is required.

📁 Advanced: Separate Files, Direct Download

Download from GitHub: [Latest Release](https://github.com/gitbrent/PptxGenJS/releases/latest)

```html
<script src="PptxGenJS/dist/pptxgen.min.js"></script>
```

## 🚀 Universal Compatibility

PptxGenJS works seamlessly in **modern web and Node environments**, thanks to dual ESM and CJS builds and a bundled browser ZIP implementation. Whether you're building a CLI tool, an Electron app, or a web-based presentation builder, the library adapts automatically to your stack.

### Supported Platforms

- **Node.js** – generate presentations in backend scripts, APIs, or CLI tools
- **React / Angular / Vite / Webpack** – just import and go, no config required
- **Electron** – build native apps with full filesystem access and PowerPoint output
- **Browser (Vanilla JS)** – embed in web apps with caller-owned writable destinations
- **Serverless / Edge Functions** – use in AWS Lambda, Vercel, Cloudflare Workers, etc.

> _Vite, Webpack, and modern bundlers automatically select the right build via the `exports` field in `package.json`._

### Builds Provided

- **CommonJS**: [`dist/pptxgen.cjs.js`](./dist/pptxgen.cjs.js)
- **ES Module**: [`dist/pptxgen.es.js`](./dist/pptxgen.es.js)

## 📖 Documentation

### Quick Start Guide

PptxGenJS PowerPoint presentations are created via JavaScript by following 4 basic steps:

#### Node.js / server-side TypeScript

```typescript
import pptxgen from "pptxgenjs";
import { createWriteStream } from "node:fs";

// 1. Create a new Presentation
let pres = new pptxgen();

// 2. Add a Slide
let slide = pres.addSlide();

// 3. Add one or more objects (Tables, Shapes, Images, Text and Media) to the Slide
let textboxText = "Hello World from PptxGenJS!";
let textboxOpts = { x: 1, y: 1, color: "363636" };
slide.addText(textboxText, textboxOpts);

// 4. Stream the Presentation to the destination
await pres.writeTo({
  destination: createWriteStream("Presentation.pptx"),
});
```

#### Script/Web Browser

```javascript
// 1. Create a new Presentation
let pres = new PptxGenJS();

// 2. Add a Slide
let slide = pres.addSlide();

// 3. Add one or more objects (Tables, Shapes, Images, Text and Media) to the Slide
let textboxText = "Hello World from PptxGenJS!";
let textboxOpts = { x: 1, y: 1, color: "363636" };
slide.addText(textboxText, textboxOpts);

// 4. Acquire an explicit destination during the user gesture, then stream to it
const fileHandle = await window.showSaveFilePicker({
  suggestedName: "Presentation.pptx",
  types: [{
    description: "PowerPoint presentation",
    accept: {
      "application/vnd.openxmlformats-officedocument.presentationml.presentation": [".pptx"],
    },
  }],
});
await pres.writeTo({ destination: await fileHandle.createWritable() });
```

Applications without the File System Access API must provide another
`WritableStream` destination instead of falling back to a complete in-memory
Blob.

## 📊 Streaming table pagination

v5 removes the legacy DOM-capture API. Convert HTML or other application data
to typed `TableRow` values in your own adapter, then pass those rows to the
streaming session:

```javascript
const pptx = new PptxGenJS();
const session = await pptx.beginStreaming({ destination });

await session.tableToSlides([
  [
    { text: "Name", options: { bold: true } },
    { text: "Value", options: { bold: true } },
  ],
  [
    { text: "Alpha" },
    { text: "42" },
  ],
], {
  x: 0.5,
  y: 0.5,
  w: 9,
  h: 4.5,
  autoPage: true,
});

await session.finalize();
```

This keeps DOM measurement and application-specific HTML parsing outside the
core package while retaining typed cells, colspan support, and bounded
forward-only pagination.

## 📚 Full Documentation

Complete API reference, tutorials, and integration guides are available on the official docs site: [https://gitbrent.github.io/PptxGenJS](https://gitbrent.github.io/PptxGenJS)

## 🛠️ Issues / Suggestions

Please file issues or suggestions on the [issues page on github](https://github.com/gitbrent/PptxGenJS/issues/new), or even better, [submit a pull request](https://github.com/gitbrent/PptxGenJS/pulls). Feedback is always welcome!

When reporting issues, please include a code snippet or a link demonstrating the problem.
Here is a small [jsFiddle](https://jsfiddle.net/gitbrent/L1uctxm0/) that is already configured and uses the latest PptxGenJS code.

## 🆘 Need Help?

Sometimes implementing a new library can be a difficult task and the slightest mistake will keep something from working. We've all been there!

If you are having issues getting a presentation to generate, check out the code in the `demos` directory. There
are demos for browser, node and, react that contain working examples of every available library feature.

- Use a pre-configured jsFiddle to test with: [PptxGenJS Fiddle](https://jsfiddle.net/gitbrent/L1uctxm0/)
- [View questions tagged `PptxGenJS` on StackOverflow](https://stackoverflow.com/questions/tagged/pptxgenjs?sort=votes&pageSize=50). If you can't find your question, [ask it yourself](https://stackoverflow.com/questions/ask?tags=PptxGenJS) - be sure to tag it `pptxgenjs`.
- Ask your AI pair programmer! All major LLMs have ingested the pptxgenjs library and have the ability to answer functionality questions and provide code.

## 🙏 Contributors

Thank you to everyone for the contributions and suggestions! ❤️

Special Thanks:

- [Dzmitry Dulko](https://github.com/DzmitryDulko) - Getting the project published on NPM
- [Michal Kacerovský](https://github.com/kajda90) - New Master Slide Layouts and Chart expertise
- [Connor Bowman](https://github.com/conbow) - Adding Placeholders
- [Reima Frgos](https://github.com/ReimaFrgos) - Multiple chart and general functionality patches
- [Matt King](https://github.com/kyrrigle) - Chart expertise
- [Mike Wilcox](https://github.com/clubajax) - Chart expertise
- [Joonas](https://github.com/wyozi) - [react-pptx](https://github.com/wyozi/react-pptx)

PowerPoint shape definitions and some XML code via [Officegen Project](https://github.com/Ziv-Barber/officegen)

## 🌟 Support the Open Source Community

If you find this library useful, consider contributing to open-source projects, or sharing your knowledge on the open social web. Together, we can build free tools and resources that empower everyone.

[@gitbrent@fosstodon.org](https://fosstodon.org/@gitbrent)

## 📜 License

Copyright &copy; 2015-present [Brent Ely](https://github.com/gitbrent/)

[MIT](https://github.com/gitbrent/PptxGenJS/blob/master/LICENSE)
